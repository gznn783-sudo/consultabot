python bot.py
